#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
import re
import json
import threading
import shutil
import zipfile
import tempfile
import subprocess
from pathlib import Path
from typing import List, Dict, Optional

import requests
from PyQt5 import QtCore, QtGui, QtWidgets

BG_COLOR = "#0a0a0a"
NEON = "#00ff99"
ACCENT1 = "#00ffaa"
ACCENT2 = "#009966"
FONT_FAMILY = "Orbitron, Inter, sans-serif"

FONT_SIZE_LARGE = "16px"
FONT_SIZE_MEDIUM = "14px" 
FONT_SIZE_SMALL = "12px"
ICON_SIZE = 24

DEFAULT_LOGO_TEXT = "🌐 STv2 Installer"
CUSTOM_LOGO_PATH = "icons/logo.png"
CUSTOM_ICON_PATH = "icons/icon.png"

SITE_ROOT = "https://pixelglimmer.github.io/"
TOOLS_SCRIPT_ID = "tools-data"

CONFIG_PATH = Path.home() / ".pixelglimmer_installer_config.json"

def load_config() -> dict:
    if CONFIG_PATH.exists():
        try:
            return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}

def save_config(cfg: dict):
    try:
        CONFIG_PATH.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass

def safe_filename_from_url(url: str) -> str:
    name = os.path.basename(url.split("?", 1)[0])
    if not name:
        name = "downloaded_file"
    return name

def human_size(num_bytes: Optional[int]) -> str:
    if num_bytes is None:
        return "?"
    try:
        b = float(num_bytes)
    except Exception:
        return "?"
    for unit in ["B","KB","MB","GB","TB"]:
        if b < 1024.0:
            return f"{b:3.1f} {unit}"
        b /= 1024.0
    return f"{b:.1f} PB"

def load_programs_from_site(site_url: str = SITE_ROOT, timeout: int = 10) -> List[dict]:
    try:
        r = requests.get(site_url, timeout=timeout)
        r.raise_for_status()
        html = r.text
    except Exception as e:
        raise RuntimeError(f"Ошибка загрузки страницы {site_url}: {e}")

    m = re.search(rf'<script[^>]*id=["\']{re.escape(TOOLS_SCRIPT_ID)}["\'][^>]*>(.*?)</script>', html, re.S | re.I)
    if not m:
        raise RuntimeError(f"Тег <script id=\"{TOOLS_SCRIPT_ID}\"> не найден на странице {site_url}")

    json_text = m.group(1).strip()
    try:
        data = json.loads(json_text)
    except Exception as e:
        raise RuntimeError(f"Ошибка парсинга JSON из тега {TOOLS_SCRIPT_ID}: {e}")

    programs = []
    icon_map = {
        "system": "⚙️",
        "monitoring": "📊",
        "remote": "🌐",
        "network": "🌐",
        "automation": "🤖",
        "productivity": "💼",
        "streaming": "🎥",
        "tweaks": "🛠️",
        "cleanup": "🧹",
        "archiver": "📦",
        "virtualization": "🖥️",
        "dev": "💻",
        "images": "🖼️",
        "ai": "🧠",
        "default": "🟩"
    }

    for item in data:
        name = item.get("name") or item.get("id") or "Unnamed"
        desc = item.get("desc") or item.get("description") or ""
        href = item.get("href") or item.get("url") or ""
        tags = item.get("tags") or []
        category = tags[0] if tags else (item.get("category") or "Other")
        icon = icon_map.get(category, icon_map.get("default"))
        size = item.get("size") or ""
        programs.append({
            "name": name,
            "description": desc,
            "category": category,
            "url": href,
            "icon": icon,
            "size": size,
            "raw": item
        })
    return programs

class InstallerWorker(QtCore.QObject):
    log_signal = QtCore.pyqtSignal(str)
    overall_progress = QtCore.pyqtSignal(int)
    file_progress = QtCore.pyqtSignal(int)
    finished = QtCore.pyqtSignal(bool, str)

    def __init__(self, items: List[dict], parent=None):
        super().__init__(parent)
        self.items = items
        self._cancel = False

    def cancel(self):
        self._cancel = True

    def _log(self, text: str):
        self.log_signal.emit(text)

    def run(self):
        success = True
        error_messages = []
        try:
            total = len(self.items)
            if total == 0:
                self.finished.emit(False, "Нет выбранных программ.")
                return
            self._log(f"Начинаю установку {total} программ...")
            
            successful_installs = 0
            failed_installs = 0
            
            for idx, item in enumerate(self.items, start=1):
                if self._cancel:
                    self._log("Установка отменена пользователем.")
                    self.finished.emit(False, "Отменено пользователем")
                    return

                name = item.get("name", "Unnamed")
                url = item.get("url")
                install_path = item.get("_install_path") or item.get("install_target") or str(Path.home())
                self._log(f"({idx}/{total}) {name} — подготовка...")
                
                if not url:
                    error_msg = f"Для {name} не указан URL"
                    self._log(f"Пропущено: {error_msg}")
                    error_messages.append(error_msg)
                    failed_installs += 1
                    continue

                safe_folder_name = "".join(c for c in name if c.isalnum() or c in " _-")[:200].strip() or "program"
                dest_dir = os.path.join(install_path, safe_folder_name)
                os.makedirs(dest_dir, exist_ok=True)

                tmp_path = None
                try:
                    self._log(f"Скачиваю {name}...")
                    tmp_fd, tmp_path = tempfile.mkstemp()
                    os.close(tmp_fd)
                    
                    with requests.get(url, stream=True, timeout=60) as r:
                        r.raise_for_status()
                        total_len = r.headers.get("Content-Length")
                        total_len_i = int(total_len) if total_len and total_len.isdigit() else None
                        downloaded = 0
                        chunk = 8192
                        
                        cd = r.headers.get("content-disposition", "")
                        derived_name = None
                        m = re.search(r'filename\*=UTF-8\'\'(.+)', cd)
                        if m:
                            derived_name = m.group(1)
                        elif 'filename=' in cd:
                            m2 = re.search(r'filename="?([^";]+)"?', cd)
                            if m2:
                                derived_name = m2.group(1)
                        
                        url_name = safe_filename_from_url(url)
                        if derived_name:
                            filename_to_use = derived_name
                        else:
                            filename_to_use = url_name
                            
                        with open(tmp_path, "wb") as f:
                            for chunk_bytes in r.iter_content(chunk_size=chunk):
                                if self._cancel:
                                    f.close()
                                    if tmp_path and os.path.exists(tmp_path):
                                        os.remove(tmp_path)
                                    self.finished.emit(False, "Отменено пользователем")
                                    return
                                if chunk_bytes:
                                    f.write(chunk_bytes)
                                    downloaded += len(chunk_bytes)
                                    if total_len_i:
                                        self.file_progress.emit(int(downloaded * 100 / total_len_i))
                                        
                        self.file_progress.emit(100)
                        
                        lowered = url.lower()
                        ct = r.headers.get("Content-Type", "").lower()
                        is_zip = lowered.endswith(".zip") or "zip" in ct or filename_to_use.lower().endswith('.zip')
                        
                        if is_zip:
                            self._log("Распаковка архива...")
                            try:
                                with zipfile.ZipFile(tmp_path, 'r') as zf:
                                    zf.extractall(dest_dir)
                                if tmp_path and os.path.exists(tmp_path):
                                    os.remove(tmp_path)
                                self._log(f"{name}: распаковано в {dest_dir}")
                                successful_installs += 1
                            except Exception as e:
                                error_msg = f"Ошибка распаковки ZIP для {name}: {e}"
                                self._log(error_msg)
                                error_messages.append(error_msg)
                                try:
                                    target = os.path.join(dest_dir, filename_to_use)
                                    if tmp_path and os.path.exists(tmp_path):
                                        shutil.move(tmp_path, target)
                                    self._log(f"{name}: файл сохранён → {target}")
                                    successful_installs += 1
                                except Exception as fallback_e:
                                    error_msg = f"Ошибка сохранения файла для {name}: {fallback_e}"
                                    self._log(error_msg)
                                    error_messages.append(error_msg)
                                    failed_installs += 1
                        else:
                            target = os.path.join(dest_dir, filename_to_use)
                            if tmp_path and os.path.exists(tmp_path):
                                shutil.move(tmp_path, target)
                            self._log(f"{name}: файл сохранён → {target}")
                            successful_installs += 1
                            
                except Exception as e:
                    if tmp_path and os.path.exists(tmp_path):
                        try:
                            os.remove(tmp_path)
                        except Exception:
                            pass
                    error_msg = f"Ошибка при скачивании/установке {name}: {e}"
                    self._log(error_msg)
                    error_messages.append(error_msg)
                    failed_installs += 1
                    
                overall_percent = int(idx * 100 / total)
                self.overall_progress.emit(overall_percent)

            if failed_installs == 0:
                final_message = f"Установка завершена успешно! Установлено программ: {successful_installs}"
                success = True
            else:
                final_message = f"Установка завершена с ошибками. Успешно: {successful_installs}, Ошибок: {failed_installs}"
                if error_messages:
                    final_message += "\n\nОшибки:\n" + "\n".join(error_messages[:5])
                success = False
                
            self._log(final_message)
            self.finished.emit(success, final_message)
            
        except Exception as e:
            error_msg = f"Критическая ошибка: {e}"
            self._log(error_msg)
            self.finished.emit(False, error_msg)

class ProgramItemWidget(QtWidgets.QWidget):
    def __init__(self, program: dict, default_install_path: str, parent=None):
        super().__init__(parent)
        self.program = program
        self.install_path = default_install_path

        layout = QtWidgets.QHBoxLayout()
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(12)

        self.checkbox = QtWidgets.QCheckBox()
        self.checkbox.setMinimumSize(24, 24)
        
        self.icon_label = QtWidgets.QLabel(program.get("icon", "📦"))
        self.icon_label.setFixedWidth(40)
        self.icon_label.setAlignment(QtCore.Qt.AlignCenter)
        self.icon_label.setFont(QtGui.QFont("Segoe UI Emoji", ICON_SIZE))

        title_v = QtWidgets.QVBoxLayout()
        title = QtWidgets.QLabel(program.get("name", "Unnamed"))
        title.setStyleSheet(f"font-weight:700; font-size:{FONT_SIZE_LARGE};")
        desc = QtWidgets.QLabel(program.get("description", ""))
        desc.setWordWrap(True)
        desc.setStyleSheet(f"font-size:{FONT_SIZE_MEDIUM};")
        meta = QtWidgets.QLabel(program.get("size", ""))
        meta.setStyleSheet(f"color:#bfffdc; font-size:{FONT_SIZE_SMALL};")
        title_v.addWidget(title)
        title_v.addWidget(desc)
        title_v.addWidget(meta)

        self.folder_btn = QtWidgets.QPushButton("Папка...")
        self.folder_btn.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.folder_btn.setMinimumHeight(36)
        self.folder_btn.clicked.connect(self.choose_folder)

        layout.addWidget(self.checkbox)
        layout.addWidget(self.icon_label)
        layout.addLayout(title_v, 1)
        layout.addWidget(self.folder_btn)

        self.setLayout(layout)
        self.setMinimumHeight(80)

    def choose_folder(self):
        default = self.install_path or str(Path.home())
        folder = QtWidgets.QFileDialog.getExistingDirectory(self, "Выберите папку установки", default)
        if folder:
            self.install_path = folder

    def is_checked(self) -> bool:
        return self.checkbox.isChecked()

    def get_program_data(self) -> dict:
        d = self.program.copy()
        d["_install_path"] = self.install_path
        return d

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("PixelGlimmer Installer")
        self.resize(1200, 900)
        self.setWindowIcon(self._make_icon())

        central = QtWidgets.QWidget()
        self.setCentralWidget(central)

        self.logo_widget = self._create_logo_widget()
        self.refresh_btn = QtWidgets.QPushButton("Обновить список")
        self.refresh_btn.setMinimumHeight(40)
        self.refresh_btn.clicked.connect(self.load_programs_from_site)

        top_h = QtWidgets.QHBoxLayout()
        top_h.addWidget(self.logo_widget)
        top_h.addStretch()
        top_h.addWidget(self.refresh_btn)

        self.search_edit = QtWidgets.QLineEdit()
        self.search_edit.setPlaceholderText("Поиск программ...")
        self.search_edit.setMinimumHeight(36)
        self.search_edit.textChanged.connect(self.filter_items)

        self.category_combo = QtWidgets.QComboBox()
        self.category_combo.setMinimumHeight(36)
        self.category_combo.addItem("All")
        self.category_combo.currentTextChanged.connect(self.filter_items)

        search_h = QtWidgets.QHBoxLayout()
        search_h.addWidget(self.search_edit)
        search_h.addWidget(self.category_combo)

        self.list_container = QtWidgets.QWidget()
        self.list_layout = QtWidgets.QVBoxLayout()
        self.list_layout.setSpacing(8)
        self.list_layout.addStretch()
        self.list_container.setLayout(self.list_layout)

        self.scroll = QtWidgets.QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setWidget(self.list_container)

        self.path_edit = QtWidgets.QLineEdit()
        self.path_edit.setPlaceholderText("Путь установки (сохранится)")
        self.path_edit.setMinimumHeight(36)
        cfg = load_config()
        last = cfg.get("last_install_path", str(Path.home()))
        self.path_edit.setText(last)

        choose_path_btn = QtWidgets.QPushButton("Выбрать...")
        choose_path_btn.setMinimumHeight(36)
        choose_path_btn.clicked.connect(self.choose_install_folder)

        self.install_btn = QtWidgets.QPushButton("Установить выбранные")
        self.install_btn.setObjectName("install_btn")
        self.install_btn.setMinimumHeight(40)
        self.install_btn.clicked.connect(self.start_installation)
        self.install_btn.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))

        open_folder_btn = QtWidgets.QPushButton("Открыть папку установки")
        open_folder_btn.setMinimumHeight(36)
        open_folder_btn.clicked.connect(self.open_install_folder)

        bottom_h = QtWidgets.QHBoxLayout()
        bottom_h.addWidget(self.path_edit)
        bottom_h.addWidget(choose_path_btn)
        bottom_h.addWidget(self.install_btn)
        bottom_h.addWidget(open_folder_btn)

        self.overall_progress = QtWidgets.QProgressBar()
        self.overall_progress.setValue(0)
        self.overall_progress.setMinimumHeight(20)
        self.file_progress = QtWidgets.QProgressBar()
        self.file_progress.setValue(0)
        self.file_progress.setMinimumHeight(20)
        self.status_log = QtWidgets.QTextEdit()
        self.status_log.setReadOnly(True)
        self.status_log.setFixedHeight(180)
        self.status_log.setStyleSheet(f"font-size:{FONT_SIZE_MEDIUM};")

        main_v = QtWidgets.QVBoxLayout()
        main_v.addLayout(top_h)
        main_v.addLayout(search_h)
        main_v.addWidget(self.scroll)
        main_v.addLayout(bottom_h)
        
        overall_label = QtWidgets.QLabel("Общий прогресс:")
        overall_label.setStyleSheet(f"font-size:{FONT_SIZE_MEDIUM};")
        file_label = QtWidgets.QLabel("Прогресс файла:")
        file_label.setStyleSheet(f"font-size:{FONT_SIZE_MEDIUM};")
        log_label = QtWidgets.QLabel("Лог:")
        log_label.setStyleSheet(f"font-size:{FONT_SIZE_MEDIUM};")
        
        main_v.addWidget(overall_label)
        main_v.addWidget(self.overall_progress)
        main_v.addWidget(file_label)
        main_v.addWidget(self.file_progress)
        main_v.addWidget(log_label)
        main_v.addWidget(self.status_log)

        central.setLayout(main_v)

        self.apply_styles()

        self.programs: List[dict] = []
        self.items_widgets: List[ProgramItemWidget] = []

        self._glow_timer = QtCore.QTimer()
        self._glow_timer.setInterval(700)
        self._glow_state = False
        self._glow_timer.timeout.connect(self._toggle_glow)
        self._glow_timer.start()

        self._worker_thread = None
        self._worker = None

        QtCore.QTimer.singleShot(100, self.load_programs_from_site)
        QtCore.QTimer.singleShot(200, self._check_internet)

    def _create_logo_widget(self):
        widget = QtWidgets.QWidget()
        layout = QtWidgets.QHBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        
        logo_pixmap = self._load_custom_logo()
        
        if logo_pixmap:
            logo_label = QtWidgets.QLabel()
            logo_label.setPixmap(logo_pixmap.scaled(200, 60, QtCore.Qt.KeepAspectRatio, QtCore.Qt.SmoothTransformation))
            layout.addWidget(logo_label)
        else:
            logo_label = QtWidgets.QLabel(DEFAULT_LOGO_TEXT)
            logo_label.setStyleSheet(f"font-size:24px; font-weight:800; color:{NEON};")
            layout.addWidget(logo_label)
        
        widget.setLayout(layout)
        return widget

    def _load_custom_logo(self):
        possible_paths = [
            CUSTOM_LOGO_PATH,
            os.path.join(os.path.dirname(__file__), "logo.png"),
            os.path.join(os.path.dirname(__file__), "assets", "logo.png"),
            os.path.join(os.path.dirname(__file__), "images", "logo.png"),
            "logo.png"
        ]
        
        for path in possible_paths:
            if os.path.exists(path):
                try:
                    pixmap = QtGui.QPixmap(path)
                    if not pixmap.isNull():
                        return pixmap
                except Exception:
                    continue
        return None

    def _make_icon(self) -> QtGui.QIcon:
        possible_icon_paths = [
            CUSTOM_ICON_PATH,
            os.path.join(os.path.dirname(__file__), "icon.png"),
            os.path.join(os.path.dirname(__file__), "assets", "icon.png"),
            os.path.join(os.path.dirname(__file__), "images", "icon.png"),
            "icon.png"
        ]
        
        for path in possible_icon_paths:
            if os.path.exists(path):
                try:
                    icon = QtGui.QIcon(path)
                    if not icon.isNull():
                        return icon
                except Exception:
                    continue
        
        pix = QtGui.QPixmap(64, 64)
        pix.fill(QtGui.QColor(BG_COLOR))
        p = QtGui.QPainter(pix)
        p.setRenderHint(QtGui.QPainter.Antialiasing)
        pen = QtGui.QPen(QtGui.QColor(NEON))
        pen.setWidth(4)
        p.setPen(pen)
        brush = QtGui.QBrush(QtGui.QColor(NEON))
        rect = QtCore.QRect(8, 8, 48, 48)
        p.drawRoundedRect(rect, 10, 10)
        p.setPen(QtGui.QPen(QtGui.QColor(BG_COLOR)))
        font = QtGui.QFont()
        font.setPointSize(20)
        font.setBold(True)
        p.setFont(font)
        p.drawText(rect, QtCore.Qt.AlignCenter, "PG")
        p.end()
        return QtGui.QIcon(pix)

    def apply_styles(self):
        self.setStyleSheet(f"""
            QMainWindow {{ background: {BG_COLOR}; }}
            QWidget {{ color: #e6fff2; font-family: {FONT_FAMILY}; font-size:{FONT_SIZE_MEDIUM}; }}
            QLineEdit, QTextEdit {{ 
                background: #0f0f0f; 
                border:1px solid #0f0f0f; 
                padding:8px; 
                border-radius:6px; 
                font-size:{FONT_SIZE_MEDIUM};
            }}
            QPushButton {{ 
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 {NEON}, stop:1 {ACCENT1}); 
                color:#001a12; 
                border-radius:8px; 
                padding:10px 14px; 
                font-weight:700; 
                box-shadow: 0 0 10px {NEON};
                font-size:{FONT_SIZE_MEDIUM};
            }}
            QPushButton#install_btn {{ 
                background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 {ACCENT1}, stop:1 {NEON}); 
                color:#001a12; 
                font-size:{FONT_SIZE_MEDIUM};
            }}
            QPushButton:hover {{ transform: scale(1.01); }}
            QProgressBar {{ 
                background: #071007; 
                border:1px solid #072007; 
                border-radius:6px; 
                text-align:center; 
                height:20px;
                font-size:{FONT_SIZE_SMALL};
            }}
            QProgressBar::chunk {{ 
                background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 {NEON}, stop:1 {ACCENT1}); 
                border-radius:6px; 
            }}
            QComboBox, QScrollArea {{ 
                background: transparent; 
                border-radius:6px;
                font-size:{FONT_SIZE_MEDIUM};
            }}
            QCheckBox {{
                font-size:{FONT_SIZE_MEDIUM};
            }}
            QCheckBox::indicator {{
                width: 20px;
                height: 20px;
            }}
        """)

    def _toggle_glow(self):
        self._glow_state = not self._glow_state
        if self._glow_state:
            self.install_btn.setStyleSheet(f"""
                QPushButton#install_btn {{ 
                    background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 {ACCENT1}, stop:1 {NEON}); 
                    color:#001a12; 
                    border-radius:8px; 
                    padding:10px 14px; 
                    font-weight:700; 
                    box-shadow: 0 0 18px {NEON};
                    font-size:{FONT_SIZE_MEDIUM};
                }}
            """)
        else:
            self.install_btn.setStyleSheet(f"""
                QPushButton#install_btn {{ 
                    background: qlineargradient(x1:0,y1:0,x2:0,y2:1, stop:0 {ACCENT1}, stop:1 {NEON}); 
                    color:#001a12; 
                    border-radius:8px; 
                    padding:10px 14px; 
                    font-weight:700; 
                    box-shadow: none;
                    font-size:{FONT_SIZE_MEDIUM};
                }}
            """)

    def _check_internet(self):
        self.append_log("Проверка интернет-соединения...")
        def check():
            try:
                requests.head(SITE_ROOT, timeout=4)
                self.append_log("Интернет: доступен.")
            except Exception:
                self.append_log("Интернет: недоступен. Список можно загрузить из локального файла, если он есть.")
        threading.Thread(target=check, daemon=True).start()

    def append_log(self, text: str):
        ts = QtCore.QDateTime.currentDateTime().toString()
        self.status_log.append(f"[{ts}] {text}")

    def clear_list(self):
        for i in reversed(range(self.list_layout.count())):
            w = self.list_layout.itemAt(i).widget()
            if w:
                w.setParent(None)
        self.list_layout.addStretch()

    def load_programs_from_site(self):
        self.append_log("Загружаю список программ с сайта...")
        self.programs = []
        self.items_widgets = []
        self.clear_list()
        self.category_combo.clear()
        self.category_combo.addItem("All")

        def loader():
            try:
                programs = load_programs_from_site()
                self.programs = programs
                QtCore.QMetaObject.invokeMethod(self, "_populate_programs_ui", QtCore.Qt.QueuedConnection)
                self.append_log(f"Загружено {len(programs)} программ с сайта.")
            except Exception as e:
                self.append_log(f"Ошибка загрузки с сайта: {e}")
                local = Path(__file__).with_name("programs.json")
                if local.exists():
                    try:
                        with open(local, "r", encoding="utf-8") as f:
                            data = json.load(f)
                        programs = []
                        for it in data:
                            programs.append({
                                "name": it.get("name",""),
                                "description": it.get("description",""),
                                "category": it.get("category","Other"),
                                "url": it.get("url",""),
                                "icon": it.get("icon","📦"),
                                "size": it.get("size","")
                            })
                        self.programs = programs
                        QtCore.QMetaObject.invokeMethod(self, "_populate_programs_ui", QtCore.Qt.QueuedConnection)
                        self.append_log(f"Загружено {len(programs)} программ из локального programs.json.")
                    except Exception as ee:
                        self.append_log(f"Локальный programs.json недоступен или повреждён: {ee}")

        threading.Thread(target=loader, daemon=True).start()

    @QtCore.pyqtSlot()
    def _populate_programs_ui(self):
        cats = {"All"}
        for p in self.programs:
            cats.add(p.get("category", "Other"))
        self.category_combo.blockSignals(True)
        self.category_combo.clear()
        for c in sorted(cats):
            self.category_combo.addItem(c)
        self.category_combo.blockSignals(False)

        default_path = self.path_edit.text() or str(Path.home())
        self.clear_list()
        for p in self.programs:
            w = ProgramItemWidget(p, default_install_path=default_path)
            self.list_layout.insertWidget(self.list_layout.count()-1, w)
            self.items_widgets.append(w)
        self.filter_items()

    def filter_items(self):
        term = self.search_edit.text().lower().strip()
        cat = self.category_combo.currentText()
        for w in self.items_widgets:
            name = (w.program.get("name","") or "").lower()
            desc = (w.program.get("description","") or "").lower()
            category = w.program.get("category","")
            visible = True
            if cat and cat != "All" and category != cat:
                visible = False
            if term:
                if term not in name and term not in desc:
                    visible = False
            w.setVisible(visible)

    def choose_install_folder(self):
        folder = QtWidgets.QFileDialog.getExistingDirectory(self, "Папка для установки", self.path_edit.text() or str(Path.home()))
        if folder:
            self.path_edit.setText(folder)
            cfg = load_config()
            cfg["last_install_path"] = folder
            save_config(cfg)

    def open_install_folder(self):
        folder = self.path_edit.text() or str(Path.home())
        if not os.path.exists(folder):
            QtWidgets.QMessageBox.warning(self, "Папка не найдена", "Указанная папка не найдена.")
            return
        if sys.platform == "win32":
            os.startfile(folder)
        elif sys.platform == "darwin":
            subprocess.call(["open", folder])
        else:
            subprocess.call(["xdg-open", folder])

    def start_installation(self):
        checked_widgets = [w for w in self.items_widgets if w.is_checked()]
        if not checked_widgets:
            QtWidgets.QMessageBox.information(self, "Нечего устанавливать", "Пожалуйста, отметьте программы в списке.")
            return
        items = []
        for w in checked_widgets:
            d = w.get_program_data()
            if not d.get("_install_path"):
                d["_install_path"] = self.path_edit.text() or str(Path.home())
            items.append(d)
        cfg = load_config()
        cfg["last_install_path"] = self.path_edit.text() or cfg.get("last_install_path", str(Path.home()))
        save_config(cfg)

        self.install_btn.setEnabled(False)
        self.refresh_btn.setEnabled(False)

        self._worker = InstallerWorker(items)
        self._worker_thread = QtCore.QThread()
        self._worker.moveToThread(self._worker_thread)
        self._worker_thread.started.connect(self._worker.run)
        self._worker.log_signal.connect(self.append_log)
        self._worker.overall_progress.connect(self.overall_progress.setValue)
        self._worker.file_progress.connect(self.file_progress.setValue)
        self._worker.finished.connect(self._on_install_finished)
        self._worker_thread.start()

    @QtCore.pyqtSlot(bool, str)
    def _on_install_finished(self, success: bool, message: str):
        self.append_log(message)
        
        if success:
            QtWidgets.QMessageBox.information(self, "Установка завершена", message)
        else:
            if "Установка завершена с ошибками" in message:
                QtWidgets.QMessageBox.warning(self, "Установка завершена с ошибками", message)
            else:
                QtWidgets.QMessageBox.critical(self, "Ошибка установки", message)
        
        if self._worker_thread:
            self._worker_thread.quit()
            self._worker_thread.wait(2000)
            self._worker_thread = None
            self._worker = None
            
        self.overall_progress.setValue(100 if success else 0)
        self.file_progress.setValue(0)
        self.install_btn.setEnabled(True)
        self.refresh_btn.setEnabled(True)

def main():
    app = QtWidgets.QApplication(sys.argv)
    palette = app.palette()
    palette.setColor(QtGui.QPalette.Window, QtGui.QColor(BG_COLOR))
    app.setPalette(palette)

    if hasattr(QtCore.Qt, 'AA_EnableHighDpiScaling'):
        app.setAttribute(QtCore.Qt.AA_EnableHighDpiScaling, True)
    if hasattr(QtCore.Qt, 'AA_UseHighDpiPixmaps'):
        app.setAttribute(QtCore.Qt.AA_UseHighDpiPixmaps, True)

    win = MainWindow()
    win.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main()